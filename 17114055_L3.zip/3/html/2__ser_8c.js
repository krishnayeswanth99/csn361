var 2__ser_8c =
[
    [ "nofile", "2__ser_8c.html#a49e1fa6b4860231cbcb87bd74f65569f", null ],
    [ "sendrecvflag", "2__ser_8c.html#a6e618c0ec6ffc8ac4489d11c65a5a67c", null ],
    [ "clearBuf", "2__ser_8c.html#a37e9b2e0b0fcbe7d2d5bd9c9467c1fb8", null ],
    [ "main", "2__ser_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "sendFile", "2__ser_8c.html#a19fc2d7afbfbca5d5b78534e8eeb6b29", null ]
];