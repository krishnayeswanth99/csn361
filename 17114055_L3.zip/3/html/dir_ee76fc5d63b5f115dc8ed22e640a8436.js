var dir_ee76fc5d63b5f115dc8ed22e640a8436 =
[
    [ "1.c", "1_8c.html", "1_8c" ],
    [ "2_cli.c", "2__cli_8c.html", "2__cli_8c" ],
    [ "2_ser.c", "2__ser_8c.html", "2__ser_8c" ],
    [ "3.tcl", "3_8tcl.html", "3_8tcl" ],
    [ "4.tcl", "4_8tcl.html", "4_8tcl" ],
    [ "5-bak.tcl", "5-bak_8tcl.html", "5-bak_8tcl" ],
    [ "5.tcl", "5_8tcl.html", "5_8tcl" ]
];