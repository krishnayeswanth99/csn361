var searchData=
[
  ['sendrecvflag_33',['sendrecvflag',['../2__ser_8c.html#a6e618c0ec6ffc8ac4489d11c65a5a67c',1,'2_ser.c']]]
];
