var searchData=
[
  ['main_11',['main',['../1_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;1.c'],['../2__cli_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;2_cli.c'],['../2__ser_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;2_ser.c']]]
];
