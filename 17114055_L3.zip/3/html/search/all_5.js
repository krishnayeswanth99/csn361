var searchData=
[
  ['clearbuf_7',['clearBuf',['../2__cli_8c.html#a37e9b2e0b0fcbe7d2d5bd9c9467c1fb8',1,'clearBuf(char *b):&#160;2_cli.c'],['../2__ser_8c.html#a37e9b2e0b0fcbe7d2d5bd9c9467c1fb8',1,'clearBuf(char *b):&#160;2_ser.c']]]
];
