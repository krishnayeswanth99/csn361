var searchData=
[
  ['sendfile_14',['sendFile',['../2__ser_8c.html#a19fc2d7afbfbca5d5b78534e8eeb6b29',1,'2_ser.c']]],
  ['sendrecvflag_15',['sendrecvflag',['../2__ser_8c.html#a6e618c0ec6ffc8ac4489d11c65a5a67c',1,'2_ser.c']]],
  ['separate_16',['separate',['../1_8c.html#a5f90e3b26836b8a0ff338c925198593d',1,'1.c']]]
];
