var searchData=
[
  ['nofile_32',['nofile',['../2__ser_8c.html#a49e1fa6b4860231cbcb87bd74f65569f',1,'2_ser.c']]]
];
