var indexSectionsWithContent =
{
  0: "12345cfmnrs",
  1: "12345",
  2: "cfmrs",
  3: "fns"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Macros"
};

