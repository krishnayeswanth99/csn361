var searchData=
[
  ['recvfile_13',['recvFile',['../2__cli_8c.html#a0d285ee71db2ee39e24c4a6e552991f3',1,'2_cli.c']]]
];
