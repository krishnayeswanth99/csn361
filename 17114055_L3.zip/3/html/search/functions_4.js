var searchData=
[
  ['sendfile_29',['sendFile',['../2__ser_8c.html#a19fc2d7afbfbca5d5b78534e8eeb6b29',1,'2_ser.c']]],
  ['separate_30',['separate',['../1_8c.html#a5f90e3b26836b8a0ff338c925198593d',1,'1.c']]]
];
