var 2__cli_8c =
[
    [ "flag", "2__cli_8c.html#acb7a517f6cc25250ec5e28f1c2e0df20", null ],
    [ "clearBuf", "2__cli_8c.html#a37e9b2e0b0fcbe7d2d5bd9c9467c1fb8", null ],
    [ "main", "2__cli_8c.html#a0ddf1224851353fc92bfbff6f499fa97", null ],
    [ "recvFile", "2__cli_8c.html#a0d285ee71db2ee39e24c4a6e552991f3", null ]
];