var searchData=
[
  ['func_0',['func',['../q1__cli_8c.html#ac17020a38607ab29ce18939d5194a32a',1,'func(int sockfd):&#160;q1_cli.c'],['../q1__ser_8c.html#ac17020a38607ab29ce18939d5194a32a',1,'func(int sockfd):&#160;q1_ser.c']]]
];
