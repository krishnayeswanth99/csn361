var searchData=
[
  ['port_11',['PORT',['../q1__cli_8c.html#a614217d263be1fb1a5f76e2ff7be19a2',1,'PORT():&#160;q1_cli.c'],['../q1__ser_8c.html#a614217d263be1fb1a5f76e2ff7be19a2',1,'PORT():&#160;q1_ser.c']]]
];
