var searchData=
[
  ['main_10',['main',['../q1__cli_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;q1_cli.c'],['../q1__ser_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;q1_ser.c'],['../q2_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;q2.cpp']]]
];
